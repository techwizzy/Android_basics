package com.example.autocomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

     AutoCompleteTextView acTextView;
     TextView textView;
     String [] inputs = {"Liverpool","Manchester City", "Chelsea", "Leceister", "Manchester United", "Arsenal"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        acTextView = (AutoCompleteTextView) findViewById(R.id.acTextView);
        textView = (TextView) findViewById(R.id.textView);

        textView.setText("Search for Famous EPL Teams here");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, inputs);
        acTextView.setAdapter(adapter);
    }
}